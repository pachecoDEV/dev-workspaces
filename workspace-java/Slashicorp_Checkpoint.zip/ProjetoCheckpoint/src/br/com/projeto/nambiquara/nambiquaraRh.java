package br.com.projeto.nambiquara;

import java.io.Serializable;

public class nambiquaraRh implements Serializable {
    private String duvidaCandidato;
    private String vaga;
    private String status;
}
    